package restaurantsystem;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class OrderManagementTest {

    private OrderManagement orderManagement;
    private ItemService itemService;
    private OrderService orderService;

    @Before
    public void setUp() {
        // Initialize services
        itemService = new ItemService();
        orderService = new OrderService();

        // Inject services into OrderManagement
        orderManagement = new OrderManagement();
        orderManagement.setItemService(itemService);
        orderManagement.setOrderService(orderService);

        // Clear data and set up test environment
        itemService.clearAll();
        itemService.create(new Item("Apple", 1.5, 10)); // Index 0
        itemService.create(new Item("Banana", 0.8, 20)); // Index 1
        itemService.create(new Item("Cherry", 2.0, 5));  // Index 2

        orderService.clearCart();

        // Refresh UI state
        orderManagement.performFileRelatedTask();
    }


    @Test
    public void testAddToCartButtonActionPerformed() {
        // Simulate adding an item to the cart
        orderManagement.itemIDToOrderField.setText("1"); // Apple
        orderManagement.itemOrderQuantityField.setText("5");
        orderManagement.addToCartButton.doClick();

        // Debugging: Print the state of the cart
        System.out.println("Cart contents after adding Apple:");
        orderService.getCart().getCartItems().forEach(cartItem -> {
            System.out.println(cartItem.getItem().getName() + " - Quantity: " + cartItem.getQuantity());
        });

        // Validate cart contents
        Cart cart = orderService.getCart();
        assertEquals("Cart should have one item", 1, cart.getCartItems().size());

        CartItem cartItem = cart.getCartItems().get(0);
        assertEquals("Item name should be Apple", "Apple", cartItem.getItem().getName());
        assertEquals("Quantity should be 5", 5, cartItem.getQuantity());
        assertEquals("Price should be calculated correctly", 7.5, cartItem.getPrice(), 0.01);

        // Validate receipt
        String expectedReceipt = "Apple\t5\t7.5\n";
        assertEquals("Receipt should match the added item", expectedReceipt.trim(), orderManagement.reciptArea.getText().trim());
    }


    @Test
    public void testOrderPlacement() {
        // Add items to the cart
        orderManagement.itemIDToOrderField.setText("1"); // Apple
        orderManagement.itemOrderQuantityField.setText("3");
        orderManagement.addToCartButton.doClick();

        orderManagement.itemIDToOrderField.setText("2"); // Banana
        orderManagement.itemOrderQuantityField.setText("2");
        orderManagement.addToCartButton.doClick();

        // Place the order
        orderManagement.orderButton.doClick();

        // Validate that the cart is cleared
        Cart cart = orderService.getCart();
        assertTrue("Cart should be empty after placing the order", cart.getCartItems().isEmpty());

        // Validate receipt and UI fields are cleared
        String expectedReceipt = "";
        assertEquals("Receipt area should be cleared after placing the order", expectedReceipt, orderManagement.reciptArea.getText());
        assertEquals("Total price field should be cleared after placing the order", "", orderManagement.totalPriceField.getText());

        // Validate that item quantities have been updated
        Item apple = itemService.getItemByIndex(0); // Apple
        assertNotNull("Apple item should not be null", apple);
        assertEquals("Apple quantity should be updated correctly", 7, apple.getQuantity()); // 10 - 3

        Item banana = itemService.getItemByIndex(1); // Banana
        assertNotNull("Banana item should not be null", banana);
        assertEquals("Banana quantity should be updated correctly", 18, banana.getQuantity()); // 20 - 2
    }

    @Test
    public void testEmptyCartOrder() {
        // Attempt to place an order with an empty cart
        orderManagement.orderButton.doClick();

        Cart cart = orderService.getCart();
        assertTrue("Cart should be empty", cart.getCartItems().isEmpty());

        // Validate no order was placed
        String expectedReceipt = "";
        assertEquals("Receipt should remain empty", expectedReceipt, orderManagement.reciptArea.getText());
        assertEquals("Total price field should remain empty", "", orderManagement.totalPriceField.getText());
    }

    @Test
    public void testInvalidInputHandling() {
        // Attempt to add an invalid item ID (non-numeric)
        orderManagement.itemIDToOrderField.setText("abc");
        orderManagement.itemOrderQuantityField.setText("5");
        orderManagement.addToCartButton.doClick();

        Cart cart = orderService.getCart();
        assertEquals("Cart should remain empty after invalid item ID", 0, cart.getCartItems().size());

        // Attempt to add a quantity greater than stock
        orderManagement.itemIDToOrderField.setText("1"); // Apple
        orderManagement.itemOrderQuantityField.setText("15");
        orderManagement.addToCartButton.doClick();

        assertEquals("Cart should remain empty after exceeding stock quantity", 0, cart.getCartItems().size());
    }

    @Test
    public void testAddMultipleItemsToCart() {
        // Add first item to cart
        orderManagement.itemIDToOrderField.setText("1"); // Apple
        orderManagement.itemOrderQuantityField.setText("3");
        orderManagement.addToCartButton.doClick();

        // Validate cart contents after adding the first item
        Cart cartAfterFirstItem = orderService.getCart();
        assertEquals("Cart should contain one item", 1, cartAfterFirstItem.getCartItems().size());
        CartItem firstCartItem = cartAfterFirstItem.getCartItems().get(0);
        assertEquals("First item name should be Apple", "Apple", firstCartItem.getItem().getName());
        assertEquals("First item quantity should be 3", 3, firstCartItem.getQuantity());
        assertEquals("First item price should be correct", 4.5, firstCartItem.getPrice(), 0.01);

        // Add second item to cart
        orderManagement.itemIDToOrderField.setText("2"); // Banana
        orderManagement.itemOrderQuantityField.setText("2");
        orderManagement.addToCartButton.doClick();

        // Validate cart contents after adding the second item
        Cart cartAfterSecondItem = orderService.getCart();
        assertEquals("Cart should contain two items", 2, cartAfterSecondItem.getCartItems().size());

        // Validate individual items
        CartItem secondCartItem = cartAfterSecondItem.getCartItems().get(1); // Second item
        assertEquals("Second item name should be Banana", "Banana", secondCartItem.getItem().getName());
        assertEquals("Second item quantity should be 2", 2, secondCartItem.getQuantity());
        assertEquals("Second item price should be correct", 1.6, secondCartItem.getPrice(), 0.01);

        // Validate the receipt text
        String expectedReceipt = "Apple\t3\t4.5\nBanana\t2\t1.6\n";
        assertEquals("Receipt should match the added items", expectedReceipt.trim(), orderManagement.reciptArea.getText().trim());
    }

    @Test
    public void testClearCartButtonActionPerformed() {
        // Add items to the cart
        orderManagement.itemIDToOrderField.setText("1"); // Apple
        orderManagement.itemOrderQuantityField.setText("3");
        orderManagement.addToCartButton.doClick();

        // Clear the cart
        orderManagement.clearCartButton.doClick();

        // Validate cart is cleared
        Cart cart = orderService.getCart();
        assertTrue("Cart should be empty after clearing", cart.getCartItems().isEmpty());
        assertEquals("Receipt should be cleared", "", orderManagement.reciptArea.getText());
        assertEquals("Total price field should be cleared", "", orderManagement.totalPriceField.getText());
    }
}
