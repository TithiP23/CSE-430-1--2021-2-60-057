package restaurantsystem;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

@SuppressWarnings("serial")
public class OrderManagement extends javax.swing.JFrame {

    private ItemService itemService;
    private OrderService orderService;

    public OrderManagement() {
        initComponents();
    }

    // Setter methods for dependency injection
    public void setItemService(ItemService itemService) {
        this.itemService = itemService;
    }

    public void setOrderService(OrderService orderService) {
        this.orderService = orderService;
    }



    private void initComponents() {
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        text = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        itemOrderQuantityField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        addToCartButton = new javax.swing.JButton();
        itemIDToOrderField = new javax.swing.JTextField();
        orderButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        reciptArea = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        totalPriceField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        clearCartButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        text.setEditable(false);
        text.setColumns(20);
        text.setRows(5);
        jScrollPane1.setViewportView(text);

        backButton.setText("Back");
        backButton.addActionListener(evt -> backButtonActionPerformed(evt));

        addToCartButton.setText("Add to cart");
        addToCartButton.addActionListener(evt -> addToCartButtonActionPerformed(evt));

        orderButton.setText("Order");
        orderButton.addActionListener(evt -> orderButtonActionPerformed(evt));

        clearCartButton.setText("Cancel");
        clearCartButton.addActionListener(evt -> clearCartButtonActionPerformed(evt));

        reciptArea.setEditable(false);
        reciptArea.setColumns(20);
        reciptArea.setRows(5);
        jScrollPane2.setViewportView(reciptArea);

        totalPriceField.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }

    void performFileRelatedTask() {
        StringBuilder stringBuilder = new StringBuilder();
        int num = 1;
        for (Item item : itemService.getAll()) {
            stringBuilder.append(num++)
                    .append("\t")
                    .append(item.getName())
                    .append("\t")
                    .append(item.getPrice())
                    .append("\t")
                    .append(item.getQuantity())
                    .append("\n");
        }
        text.setText(stringBuilder.toString());
    }

    private void orderButtonActionPerformed(java.awt.event.ActionEvent evt) {
        Cart cart = orderService.getCart();
        if (cart.getCartItems().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No items in cart. Please add items to the cart first.");
            return;
        }

        int lastOrderNumber = 0;
        try (Scanner scanner = new Scanner(new FileInputStream("storage/orderLine.txt"))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (!line.isEmpty()) {
                    String[] parts = line.split(",");
                    lastOrderNumber = Math.max(lastOrderNumber, Integer.parseInt(parts[0]));
                }
            }
        } catch (Exception e) {
            Logger.getLogger(OrderManagement.class.getName()).log(Level.SEVERE, null, e);
        }

        int newOrderNumber = lastOrderNumber + 1;

        try (PrintWriter writer = new PrintWriter(new FileOutputStream("storage/orderLine.txt", true))) {
            for (CartItem item : cart.getCartItems()) {
                writer.printf("%d,%s,%d,%.2f%n", newOrderNumber, item.getItem().getName(),
                        item.getQuantity(), item.getPrice());
            }
        } catch (Exception e) {
            Logger.getLogger(OrderManagement.class.getName()).log(Level.SEVERE, null, e);
        }

        try (PrintWriter writer = new PrintWriter(new FileOutputStream("storage/order.txt", true))) {
            String date = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
            writer.printf("%d,%.2f,%s%n", newOrderNumber, cart.getTotalPrice(), date);
        } catch (Exception e) {
            Logger.getLogger(OrderManagement.class.getName()).log(Level.SEVERE, null, e);
        }

        cart.getCartItems().forEach(item -> {
            itemService.reduceItemQuantityByItemName(item.getItem().getName(), item.getQuantity());
        });

        clearCartButtonActionPerformed(evt);
        performFileRelatedTask();
        JOptionPane.showMessageDialog(this, "Order placed successfully.");
    }

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {
        MainMenu mainMenu = new MainMenu();
        mainMenu.setVisible(true);
        this.dispose();
    }

    private void addToCartButtonActionPerformed(java.awt.event.ActionEvent evt) {
        String itemId = itemIDToOrderField.getText();
        String quantity = itemOrderQuantityField.getText();

        if (itemId.isEmpty() || quantity.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both item ID and quantity.");
            return;
        }

        try {
            int itemIndex = Integer.parseInt(itemId) - 1;
            int quantityInt = Integer.parseInt(quantity);

            Item item = itemService.getItemByIndex(itemIndex);
            if (item == null || quantityInt > item.getQuantity()) {
                JOptionPane.showMessageDialog(this, "Invalid item ID or quantity exceeds stock.");
                return;
            }

            CartItem cartItem = new CartItem(item, quantityInt, quantityInt * item.getPrice());
            orderService.addToCart(cartItem);

            reciptArea.setText(getReciptStringByCart());
            totalPriceField.setText(String.valueOf(orderService.getCart().getTotalPrice()));
            JOptionPane.showMessageDialog(this, "Item added to cart successfully.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numbers.");
        }
    }

    private void clearCartButtonActionPerformed(java.awt.event.ActionEvent evt) {
        orderService.clearCart();
        reciptArea.setText("");
        totalPriceField.setText("");
    }

    public String getReciptStringByCart() {
        StringBuilder receipt = new StringBuilder();
        for (CartItem item : orderService.getCart().getCartItems()) {
            receipt.append(item.getItem().getName())
                    .append("\t")
                    .append(item.getQuantity())
                    .append("\t")
                    .append(item.getPrice())
                    .append("\n");
        }
        return receipt.toString();
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new OrderManagement().setVisible(true));
    }

    // Variables declaration
    javax.swing.JButton addToCartButton;
    javax.swing.JButton backButton;
    javax.swing.JButton clearCartButton;
    javax.swing.JTextField itemIDToOrderField;
    javax.swing.JTextField itemOrderQuantityField;
    @SuppressWarnings("unused")
	private javax.swing.JLabel jLabel1;
    @SuppressWarnings("unused")
	private javax.swing.JLabel jLabel10;
    @SuppressWarnings("unused")
	private javax.swing.JLabel jLabel2;
    @SuppressWarnings("unused")
	private javax.swing.JLabel jLabel3;
    @SuppressWarnings("unused")
	private javax.swing.JLabel jLabel4;
    @SuppressWarnings("unused")
	private javax.swing.JLabel jLabel5;
    @SuppressWarnings("unused")
	private javax.swing.JLabel jLabel6;
    @SuppressWarnings("unused")
	private javax.swing.JLabel jLabel7;
    @SuppressWarnings("unused")
	private javax.swing.JLabel jLabel8;
    @SuppressWarnings("unused")
	private javax.swing.JPanel jPanel1;
    @SuppressWarnings("unused")
	private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    javax.swing.JButton orderButton;
    javax.swing.JTextArea reciptArea;
    javax.swing.JTextArea text;
    javax.swing.JTextField totalPriceField;
}