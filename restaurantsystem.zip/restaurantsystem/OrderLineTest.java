package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class OrderLineTest {

    private OrderLine orderLine;

    @Before
    public void setUp() {
        // Initialize an OrderLine instance
        orderLine = new OrderLine(1, "Apple", 5, 7.5);
    }

    @Test
    public void testGetOrderID() {
        // Validate the initial order ID
        assertEquals("Order ID should match the initialized value", 1, orderLine.getOrderID());
    }

    @Test
    public void testSetOrderID() {
        // Update the order ID
        orderLine.setOrderID(2);

        // Validate the updated order ID
        assertEquals("Order ID should be updated to the new value", 2, orderLine.getOrderID());
    }

    @Test
    public void testGetName() {
        // Validate the initial name
        assertEquals("Name should match the initialized value", "Apple", orderLine.getName());
    }

    @Test
    public void testSetName() {
        // Update the name
        orderLine.setName("Banana");

        // Validate the updated name
        assertEquals("Name should be updated to the new value", "Banana", orderLine.getName());
    }

    @Test
    public void testGetQuantity() {
        // Validate the initial quantity
        assertEquals("Quantity should match the initialized value", 5, orderLine.getQuantity());
    }

    @Test
    public void testSetQuantity() {
        // Update the quantity
        orderLine.setQuantity(10);

        // Validate the updated quantity
        assertEquals("Quantity should be updated to the new value", 10, orderLine.getQuantity());
    }

    @Test
    public void testGetPrice() {
        // Validate the initial price
        assertEquals("Price should match the initialized value", 7.5, orderLine.getPrice(), 0.01);
    }

    @Test
    public void testSetPrice() {
        // Update the price
        orderLine.setPrice(15.0);

        // Validate the updated price
        assertEquals("Price should be updated to the new value", 15.0, orderLine.getPrice(), 0.01);
    }

    @Test
    public void testFullOrderDetails() {
        // Validate all order details
        assertEquals("Order ID should be correct", 1, orderLine.getOrderID());
        assertEquals("Name should be correct", "Apple", orderLine.getName());
        assertEquals("Quantity should be correct", 5, orderLine.getQuantity());
        assertEquals("Price should be correct", 7.5, orderLine.getPrice(), 0.01);
    }

    @Test
    public void testUpdateOrderLineDetails() {
        // Update all order line details
        orderLine.setOrderID(3);
        orderLine.setName("Cherry");
        orderLine.setQuantity(12);
        orderLine.setPrice(18.0);

        // Validate the updated order line details
        assertEquals("Order ID should be updated", 3, orderLine.getOrderID());
        assertEquals("Name should be updated", "Cherry", orderLine.getName());
        assertEquals("Quantity should be updated", 12, orderLine.getQuantity());
        assertEquals("Price should be updated", 18.0, orderLine.getPrice(), 0.01);
    }
}
