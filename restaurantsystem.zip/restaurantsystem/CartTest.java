package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class CartTest {

    private Cart cart;
    private CartItem cartItem1;
    private CartItem cartItem2;

    @Before
    public void setUp() {
        // Initialize CartItems
        cartItem1 = new CartItem(new Item("Apple", 1.5, 10), 3, 4.5);
        cartItem2 = new CartItem(new Item("Banana", 0.8, 20), 5, 4.0);

        // Create Cart with initial items
        List<CartItem> cartItems = new ArrayList<>();
        cartItems.add(cartItem1);

        cart = new Cart(cartItems, 0); // Total price will be calculated dynamically
    }

    @Test
    public void testAddItemToCart() {
        // Add a new item to the cart
        cart.addItemToCart(cartItem2);

        // Validate cart contents
        List<CartItem> cartItems = cart.getCartItems();
        assertEquals("Cart should contain two items", 2, cartItems.size());
        assertTrue("Cart should contain the first item", cartItems.contains(cartItem1));
        assertTrue("Cart should contain the second item", cartItems.contains(cartItem2));
    }

    @Test
    public void testGetTotalPrice() {
        // Add a second item to the cart
        cart.addItemToCart(cartItem2);

        // Validate total price calculation
        double expectedTotalPrice = 4.5 + 4.0; // Total of Apple and Banana
        assertEquals("Total price should match the sum of item prices", expectedTotalPrice, cart.getTotalPrice(), 0.01);
    }

    @Test
    public void testSetCartItems() {
        // Create a new list of CartItems
        List<CartItem> newCartItems = new ArrayList<>();
        CartItem cartItem3 = new CartItem(new Item("Cherry", 2.0, 15), 2, 4.0);
        newCartItems.add(cartItem3);

        // Update the cart's items
        cart.setCartItems(newCartItems);

        // Validate the updated cart contents
        List<CartItem> cartItems = cart.getCartItems();
        assertEquals("Cart should now contain the new items", 1, cartItems.size());
        assertEquals("Cart should contain the new item", cartItem3, cartItems.get(0));
    }

    @Test
    public void testEmptyCart() {
        // Clear the cart by setting an empty list
        cart.setCartItems(new ArrayList<>());

        // Validate that the cart is empty
        List<CartItem> cartItems = cart.getCartItems();
        assertTrue("Cart should be empty", cartItems.isEmpty());
        assertEquals("Total price should be zero for an empty cart", 0.0, cart.getTotalPrice(), 0.01);
    }

    @Test
    public void testDynamicTotalPriceCalculation() {
        // Add multiple items and validate total price updates dynamically
        cart.addItemToCart(cartItem2);

        double totalPriceAfterTwoItems = cart.getTotalPrice();
        assertEquals("Total price should match after adding two items", 8.5, totalPriceAfterTwoItems, 0.01);

        // Add another item
        CartItem cartItem3 = new CartItem(new Item("Cherry", 2.0, 15), 2, 4.0);
        cart.addItemToCart(cartItem3);

        double totalPriceAfterThreeItems = cart.getTotalPrice();
        assertEquals("Total price should match after adding three items", 12.5, totalPriceAfterThreeItems, 0.01);
    }
}
