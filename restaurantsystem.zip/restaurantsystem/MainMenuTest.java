package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MainMenuTest {

    private MainMenu mainMenu;

    @Before
    public void setUp() {
        mainMenu = new MainMenu();
        mainMenu.setVisible(true);
    }

    @Test
    public void testItemManagementButtonActionPerformed() {
        mainMenu.itemManagementButton.doClick(); // Simulate button click
        // Verify the expected behavior by checking MainMenu visibility
        assertFalse("MainMenu should not be visible after navigation to ItemManagement", mainMenu.isVisible());
    }

    @Test
    public void testLabourManagementButtonActionPerformed() {
        mainMenu.labourManagementButton.doClick(); // Simulate button click
        // Verify the expected behavior by checking MainMenu visibility
        assertFalse("MainMenu should not be visible after navigation to LabourManagement", mainMenu.isVisible());
    }

    @Test
    public void testOrderManagementButtonActionPerformed() {
        mainMenu.orderManagementButton.doClick(); // Simulate button click
        // Verify the expected behavior by checking MainMenu visibility
        assertFalse("MainMenu should not be visible after navigation to OrderManagement", mainMenu.isVisible());
    }

    @Test
    public void testExitButtonActionPerformed() {
        // Override the default exit behavior for testing
        mainMenu.exitButton.addActionListener(e -> mainMenu.dispose());

        mainMenu.exitButton.doClick(); // Simulate button click
        assertFalse("Application should exit on exitButton click", mainMenu.isVisible());
    }

    @Test
    public void testButtonDisabledState() {
        mainMenu.itemManagementButton.setEnabled(false); // Simulate disabled button
        mainMenu.itemManagementButton.doClick(); // Try to click it
        assertTrue("MainMenu should remain visible when clicking a disabled button", mainMenu.isVisible());
    }

    @Test
    public void testNavigationWithoutMocking() {
        // Manually verify navigation logic
        mainMenu.itemManagementButton.addActionListener(e -> {
            ItemManagement itemManagement = new ItemManagement();
            itemManagement.setVisible(true);
            mainMenu.dispose();
            assertTrue("ItemManagement should be visible after navigation", itemManagement.isVisible());
        });

        mainMenu.itemManagementButton.doClick(); // Simulate button click
    }
}

