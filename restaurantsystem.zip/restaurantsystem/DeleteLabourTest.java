package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class DeleteLabourTest {

    private DeleteLabour deleteLabour;

    @Before
    public void setUp() {
        // Clear the file before each test
        try (PrintWriter pw = new PrintWriter("storage/labour.txt")) {
            pw.print(""); // Clear content
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Initialize DeleteLabour form
        deleteLabour = new DeleteLabour();
        deleteLabour.setVisible(true);
    }

    @Test
    public void testPerformFileRelatedTask1() {
        LabourService labourService = new LabourService();
        labourService.create(new Labour("1", "Alice", 3000.0));
        labourService.create(new Labour("2", "Bob", 4000.0));

        deleteLabour.performFileRelatedTask();

        String actualText = deleteLabour.getTextArea().getText();
        System.out.println("Actual Text Area Content: " + actualText);

        String expectedText = "1\tAlice\t3000.0\n2\tBob\t4000.0\n";

        assertEquals("Text area should contain labour data", expectedText, actualText);
    }

    @Test
    public void testDeleteButtonActionPerformedWithValidID() {
        LabourService labourService = new LabourService();
        labourService.create(new Labour("1", "John Doe", 5000.0));

        deleteLabour.getLabourIDField().setText("1");
        deleteLabour.getDeleteButton().doClick();

        assertEquals("Labour ID field should be cleared after deletion", "", deleteLabour.getLabourIDField().getText());
        assertFalse("Labour with ID 1 should not exist after deletion", labourService.getAll().stream().anyMatch(l -> l.getId().equals("1")));
    }

    @Test
    public void testDeleteButtonActionPerformedWithEmptyID() {
        deleteLabour.getLabourIDField().setText("");

        deleteLabour.getDeleteButton().doClick();

        assertEquals("Labour ID field should remain empty", "", deleteLabour.getLabourIDField().getText());
    }

    @Test
    public void testDeleteButtonActionPerformedWithNonexistentID() {
        deleteLabour.getLabourIDField().setText("999");
        deleteLabour.getDeleteButton().doClick();

        assertEquals("Labour ID field should be cleared after trying to delete nonexistent ID", "", deleteLabour.getLabourIDField().getText());
    }

    @Test
    public void testBackButtonActionPerformed() {
        deleteLabour.getBackButton().doClick();

        assertFalse("DeleteLabour frame should not be visible after clicking Back", deleteLabour.isVisible());
    }

    @Test
    public void testPerformFileRelatedTask() {
        // Simulate adding labour entries
        LabourService labourService = new LabourService();
        labourService.create(new Labour("1", "Alice", 3000.0));
        labourService.create(new Labour("2", "Bob", 4000.0));

        // Refresh the text area
        deleteLabour.performFileRelatedTask();

        // Debugging the text area content
        String actualText = deleteLabour.getTextArea().getText();
        System.out.println("Actual Text Area Content: " + actualText);

        // Expected content
        String expectedText = "1\tAlice\t3000.0\n2\tBob\t4000.0\n";

        // Assert the text area contains the expected content
        assertEquals("Text area should contain labour data", expectedText, actualText);
    }

}
