package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class LabourManagementTest {

    private LabourManagement labourManagement;

    @Before
    public void setUp() {
        labourManagement = new LabourManagement();
        labourManagement.setVisible(true);
    }

    @Test
    public void testAddLabourButtonActionPerformed() {
        labourManagement.addLabour.doClick(); // Simulate button click
        assertFalse("LabourManagement frame should be closed after AddLabour button click", labourManagement.isVisible());
    }

    @Test
    public void testViewLabourButtonActionPerformed() {
        labourManagement.viewLabour.doClick(); // Simulate button click
        assertFalse("LabourManagement frame should be closed after ViewLabour button click", labourManagement.isVisible());
    }

    @Test
    public void testDeleteLabourButtonActionPerformed() {
        labourManagement.deleteLabour.doClick(); // Simulate button click
        assertFalse("LabourManagement frame should be closed after DeleteLabour button click", labourManagement.isVisible());
    }

    @Test
    public void testUpdateLabourButtonActionPerformed() {
        labourManagement.updateLabour.doClick(); // Simulate button click
        assertFalse("LabourManagement frame should be closed after UpdateLabour button click", labourManagement.isVisible());
    }

    @Test
    public void testBackButtonActionPerformed() {
        labourManagement.jButton6.doClick(); // Simulate button click
        assertFalse("LabourManagement frame should be closed after Back button click", labourManagement.isVisible());
    }
}
