package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;

import static org.junit.Assert.*;

public class MainTest {

    @Before
    public void setUp() {
        Main.createRequiredFileIfDoesNotExist();
    }

    @Test
    public void testCreateRequiredFileIfDoesNotExist() {
        String[] expectedFiles = {
            "storage/item.txt", 
            "storage/labour.txt", 
            "storage/order.txt", 
            "storage/orderLine.txt"
        };

        for (String fileName : expectedFiles) {
            File file = new File(fileName);
            assertTrue(file.exists());
        }
    }

    @Test
    public void testFileCreationFailure() {
        // Use a temporary directory to simulate inaccessible storage
        Path tempDir = null;
        try {
            tempDir = Files.createTempDirectory("test_storage");
            tempDir.toFile().setWritable(false); // Make directory inaccessible

            // Temporarily redirect storage path to the inaccessible directory
            @SuppressWarnings("unused")
			String originalStoragePath = "storage";
            System.setProperty("storage.path", tempDir.toAbsolutePath().toString());

            Main.createRequiredFileIfDoesNotExist();

            // Check that no files were created
            for (String fileName : new String[]{"item.txt", "labour.txt", "order.txt", "orderLine.txt"}) {
                File file = new File(tempDir.toAbsolutePath() + "/" + fileName);
                assertFalse(file.exists());
            }

        } catch (Exception e) {
            // If an exception occurs, ensure it's caught for test safety
            fail("Unexpected exception during test: " + e.getMessage());
        } finally {
            // Restore original storage path and clean up
            if (tempDir != null) {
                try {
                    Files.setPosixFilePermissions(tempDir, PosixFilePermissions.fromString("rwxrwxrwx")); // Restore permissions
                    Files.deleteIfExists(tempDir);
                } catch (Exception ignored) {
                }
            }
        }
    }
}
