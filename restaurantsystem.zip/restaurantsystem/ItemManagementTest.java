package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ItemManagementTest {

    private ItemManagement itemManagement;

    @Before
    public void setUp() {
        itemManagement = new ItemManagement();
        itemManagement.setVisible(true);
    }

    @Test
    public void testAddButtonActionPerformed() {
        // Simulate the add button click
        itemManagement.getAddButton().doClick();

        // Assert that the current window is closed
        assertFalse("ItemManagement window should not be visible after Add Item", itemManagement.isVisible());

        // Verify that the AddItem window is created
        AddItem addItem = new AddItem();
        addItem.setVisible(true);
        assertTrue("AddItem window should be visible", addItem.isVisible());
        addItem.dispose();
    }

    @Test
    public void testViewButtonActionPerformed() {
        // Simulate the view button click
        itemManagement.getViewButton().doClick();

        // Assert that the current window is closed
        assertFalse("ItemManagement window should not be visible after View Item", itemManagement.isVisible());

        // Verify that the ViewItem window is created
        ViewItem viewItem = new ViewItem();
        viewItem.setVisible(true);
        assertTrue("ViewItem window should be visible", viewItem.isVisible());
        viewItem.dispose();
    }

    @Test
    public void testDeleteButtonActionPerformed() {
        // Simulate the delete button click
        itemManagement.getDeleteButton().doClick();

        // Assert that the current window is closed
        assertFalse("ItemManagement window should not be visible after Delete Item", itemManagement.isVisible());

        // Verify that the DeleteItem window is created
        DeleteItem deleteItem = new DeleteItem();
        deleteItem.setVisible(true);
        assertTrue("DeleteItem window should be visible", deleteItem.isVisible());
        deleteItem.dispose();
    }

    @Test
    public void testModifyButtonActionPerformed() {
        // Simulate the modify button click
        itemManagement.getModifyButton().doClick();

        // Assert that the current window is closed
        assertFalse("ItemManagement window should not be visible after Modify Item", itemManagement.isVisible());

        // Verify that the UpdateItem window is created
        UpdateItem updateItem = new UpdateItem();
        updateItem.setVisible(true);
        assertTrue("UpdateItem window should be visible", updateItem.isVisible());
        updateItem.dispose();
    }

    @Test
    public void testBackButtonActionPerformed() {
        // Simulate the back button click
        itemManagement.getBackButton().doClick();

        // Assert that the current window is closed
        assertFalse("ItemManagement window should not be visible after clicking Back", itemManagement.isVisible());

        // Verify that the MainMenu window is created
        MainMenu mainMenu = new MainMenu();
        mainMenu.setVisible(true);
        assertTrue("MainMenu window should be visible", mainMenu.isVisible());
        mainMenu.dispose();
    }
}
