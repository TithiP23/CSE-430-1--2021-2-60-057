package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class ViewLabourTest {

    private ViewLabour viewLabour;

    @Before
    public void setUp() {
        // Clear the labour storage file before each test
        try (PrintWriter pw = new PrintWriter("storage/labour.txt")) {
            pw.print(""); // Clear content
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Add test data to the labour storage
        LabourService labourService = new LabourService();
        labourService.create(new Labour("1", "Alice", 3000.0));
        labourService.create(new Labour("2", "Bob", 4000.0));

        // Initialize the ViewLabour form
        viewLabour = new ViewLabour();
        viewLabour.setVisible(true);
    }

    @Test
    public void testPerformFileRelatedTask() {
        // Assert the text area content
        String expectedText = "1\tAlice\t3000.0\n2\tBob\t4000.0\n";
        String actualText = viewLabour.getTextArea().getText();
        assertEquals("Text area should contain labour data", expectedText, actualText);
    }

    @Test
    public void testBackButtonActionPerformed() {
        // Simulate the back button click
        viewLabour.getBackButton().doClick();

        // Assert that the ViewLabour frame is closed
        assertFalse("ViewLabour frame should not be visible after clicking Back", viewLabour.isVisible());
    }
}
