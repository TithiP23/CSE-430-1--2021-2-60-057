package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class AddLabourTest {

    private AddLabour addLabour;

    @Before
    public void setUp() {
        addLabour = new AddLabour();
        addLabour.setVisible(true);
    }

    @Test
    public void testAddButtonActionPerformedWithValidInput() {
        // Set valid input values
        addLabour.getLabourIdField().setText("1");
        addLabour.getLabourNameField().setText("John Doe");
        addLabour.getLabourSalaryField().setText("5000");

        // Simulate the add button click
        addLabour.getAddButton().doClick();

        // Assert that fields are cleared after adding
        assertEquals("Labour ID field should be cleared after adding", "", addLabour.getLabourIdField().getText());
        assertEquals("Labour Name field should be cleared after adding", "", addLabour.getLabourNameField().getText());
        assertEquals("Labour Salary field should be cleared after adding", "", addLabour.getLabourSalaryField().getText());
    }

    @Test
    public void testAddButtonActionPerformedWithEmptyFields() {
        // Set empty input values
        addLabour.getLabourIdField().setText("");
        addLabour.getLabourNameField().setText("");
        addLabour.getLabourSalaryField().setText("");

        // Simulate the add button click
        addLabour.getAddButton().doClick();

        // Assert that the fields remain unchanged
        assertEquals("Labour ID field should remain empty", "", addLabour.getLabourIdField().getText());
        assertEquals("Labour Name field should remain empty", "", addLabour.getLabourNameField().getText());
        assertEquals("Labour Salary field should remain empty", "", addLabour.getLabourSalaryField().getText());
    }

    @Test
    public void testAddButtonActionPerformedWithInvalidSalary() {
        // Set invalid salary value
        addLabour.getLabourIdField().setText("1");
        addLabour.getLabourNameField().setText("John Doe");
        addLabour.getLabourSalaryField().setText("-1000");

        // Simulate the add button click
        addLabour.getAddButton().doClick();

        // Assert that fields remain unchanged
        assertEquals("Labour Salary field should remain unchanged", "-1000", addLabour.getLabourSalaryField().getText());
    }

    @Test
    public void testLabourIdFieldActionPerformedWithValidInput() {
        // Set valid Labour ID and simulate action
        addLabour.getLabourIdField().setText("123");
        addLabour.getLabourIdField().postActionEvent();

        // Assert that the field contains the correct value
        assertEquals("Labour ID field should accept numeric input", "123", addLabour.getLabourIdField().getText());
    }

    @Test
    public void testLabourIdFieldActionPerformedWithInvalidInput() {
        // Set invalid Labour ID and simulate action
        addLabour.getLabourIdField().setText("abc");
        addLabour.getLabourIdField().postActionEvent();

        // Assert that the field is cleared after invalid input
        assertEquals("Labour ID field should be cleared after invalid input", "", addLabour.getLabourIdField().getText());
    }

    @Test
    public void testBackButtonActionPerformed() {
        // Simulate the back button click
        addLabour.getBackButton().doClick();

        // Assert that the AddLabour frame is closed
        assertFalse("AddLabour frame should not be visible after clicking Back", addLabour.isVisible());
    }
}
