package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class OrderTest {

    private Order order;

    @Before
    public void setUp() {
        // Initialize the Order object before each test
        order = new Order(101, 250.75, "2023-12-25");
    }

    @Test
    public void testGetOrderID() {
        // Assert the initial order ID
        assertEquals("Order ID should be 101", 101, order.getOrderID());
    }

    @Test
    public void testSetOrderID() {
        // Update the order ID
        order.setOrderID(102);

        // Assert the updated order ID
        assertEquals("Order ID should be updated to 102", 102, order.getOrderID());
    }

    @Test
    public void testGetPrice() {
        // Assert the initial price
        assertEquals("Price should be 250.75", 250.75, order.getPrice(), 0.01);
    }

    @Test
    public void testSetPrice() {
        // Update the price
        order.setPrice(300.50);

        // Assert the updated price
        assertEquals("Price should be updated to 300.50", 300.50, order.getPrice(), 0.01);
    }

    @Test
    public void testGetDate() {
        // Assert the initial date
        assertEquals("Date should be 2023-12-25", "2023-12-25", order.getDate());
    }

    @Test
    public void testSetDate() {
        // Update the date
        order.setDate("2023-12-26");

        // Assert the updated date
        assertEquals("Date should be updated to 2023-12-26", "2023-12-26", order.getDate());
    }

    @Test
    public void testOrderObjectInitialization() {
        // Assert all fields of the initialized object
        assertEquals("Order ID should be 101", 101, order.getOrderID());
        assertEquals("Price should be 250.75", 250.75, order.getPrice(), 0.01);
        assertEquals("Date should be 2023-12-25", "2023-12-25", order.getDate());
    }
}
