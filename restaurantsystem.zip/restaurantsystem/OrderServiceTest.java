package restaurantsystem;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class OrderServiceTest {

    private OrderService orderService;

    @Before
    public void setUp() {
        // Initialize the OrderService before each test
        orderService = new OrderService();
    }

    @Test
    public void testAddToCart() {
        // Create a CartItem
        Item apple = new Item("Apple", 1.5, 10);
        CartItem cartItem = new CartItem(apple, 3, 4.5);

        // Add the item to the cart
        orderService.addToCart(cartItem);

        // Validate the cart contents
        Cart cart = orderService.getCart();
        assertEquals("Cart should have one item", 1, cart.getCartItems().size());

        CartItem retrievedCartItem = cart.getCartItems().get(0);
        assertEquals("Item name should match", "Apple", retrievedCartItem.getItem().getName());
        assertEquals("Quantity should match", 3, retrievedCartItem.getQuantity());
        assertEquals("Price should match", 4.5, retrievedCartItem.getPrice(), 0.01);
    }

    @Test
    public void testClearCart() {
        // Add items to the cart
        Item apple = new Item("Apple", 1.5, 10);
        CartItem cartItem = new CartItem(apple, 3, 4.5);
        orderService.addToCart(cartItem);

        // Validate the cart is not empty
        assertFalse("Cart should not be empty", orderService.getCart().getCartItems().isEmpty());

        // Clear the cart
        orderService.clearCart();

        // Validate the cart is now empty
        assertTrue("Cart should be empty after clearing", orderService.getCart().getCartItems().isEmpty());
    }

    @Test
    public void testGetCart() {
        // Validate that the cart is initialized correctly
        Cart cart = orderService.getCart();
        assertNotNull("Cart should not be null", cart);
        assertTrue("Cart should be empty initially", cart.getCartItems().isEmpty());
        assertEquals("Total price should be 0 initially", 0, cart.getTotalPrice(), 0.01);

        // Add an item to the cart
        Item banana = new Item("Banana", 0.8, 20);
        CartItem cartItem = new CartItem(banana, 5, 4.0);
        orderService.addToCart(cartItem);

        // Validate the cart contents
        cart = orderService.getCart();
        assertEquals("Cart should have one item", 1, cart.getCartItems().size());
        assertEquals("Total price should match", 4.0, cart.getTotalPrice(), 0.01);
    }
}
