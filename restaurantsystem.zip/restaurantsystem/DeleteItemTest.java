package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

import static org.junit.Assert.*;

public class DeleteItemTest {

    private DeleteItem deleteItem;
    private ItemService itemService;

    @Before
    public void setUp() {
        try (PrintWriter pw = new PrintWriter("storage/item.txt")) {
            pw.print("");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        itemService = new ItemService();
        deleteItem = new DeleteItem();
        deleteItem.setVisible(true);
    }

    @Test
    public void testDeleteButtonActionPerformedWithValidName() {
        itemService.create(new Item("Apple", 1.5, 10));
        deleteItem.getDltTextField().setText("Apple");
        deleteItem.getDeleteButton().doClick();
        assertNull(itemService.getAll().stream().filter(i -> i.getName().equals("Apple")).findFirst().orElse(null));
        assertEquals("", deleteItem.getDltTextField().getText());
    }

    @Test
    public void testDeleteButtonActionPerformedWithEmptyName() {
        deleteItem.getDltTextField().setText("");
        deleteItem.getDeleteButton().doClick();
        assertEquals("", deleteItem.getDltTextField().getText());
    }

    @Test
    public void testBackButtonActionPerformed() {
        deleteItem.getBackButton().doClick();
        assertFalse(deleteItem.isVisible());
        ItemManagement itemManagement = new ItemManagement();
        itemManagement.setVisible(true);
        assertTrue(itemManagement.isVisible());
        itemManagement.dispose();
    }

    @Test
    public void testPerformFileRelatedTask() {
        itemService.create(new Item("Apple", 1.5, 10));
        deleteItem.performFileRelatedTask();
        String expectedText = "Apple\t1.5\t10\n";
        assertEquals(expectedText, deleteItem.getTextArea().getText());
    }
}
