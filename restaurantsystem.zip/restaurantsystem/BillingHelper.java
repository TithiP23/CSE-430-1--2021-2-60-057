package restaurantsystem;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;

public class BillingHelper {

    private Scanner scan;
    private StringBuilder fullnames;

    public BillingHelper() {
        fullnames = new StringBuilder();
        try {
            openFile();
            readFile();
        } catch (Exception e) {
            // Gracefully handle missing or unreadable file
            System.out.println("Error reading file: " + e.getMessage());
        } finally {
            closeFile();
        }
    }

    public StringBuilder getFullNames() {
        return fullnames;
    }

    public String getTotal() {
        double totalPrice = 0;

        try (Scanner scan = new Scanner(new FileInputStream("storage/order.txt"))) {
            while (scan.hasNextLine()) {
                scan.nextLine(); // Skip name
                scan.nextLine(); // Skip quantity
                String price = scan.nextLine(); // Read price
                totalPrice += Double.parseDouble(price);
            }
        } catch (Exception e) {
            System.out.println("Error calculating total: " + e.getMessage());
        }

        return "Total Price is : " + totalPrice;
    }

    private void openFile() {
        try {
            scan = new Scanner(new File("storage/order.txt"));
            System.out.println("File found!");
        } catch (Exception e) {
            System.out.println("File not found");
            scan = null;
        }
    }

    private void readFile() {
        if (scan == null) {
            return; // No file to read
        }

        try {
            while (scan.hasNextLine()) {
                String name = scan.nextLine();
                String quantity = scan.nextLine();
                String price = scan.nextLine();
                fullnames.append(name).append(" \t").append(quantity).append("\t").append(price).append("\n");
            }
        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    private void closeFile() {
        if (scan != null) {
            scan.close();
        }
    }
}
