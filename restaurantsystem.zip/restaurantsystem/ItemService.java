package restaurantsystem;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ItemService {

    private static final String FILE_PATH = "storage/item.txt";

    public ItemService() {
        // Ensure the file exists
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            try {
                Files.createDirectories(file.getParentFile().toPath());
                file.createNewFile();
            } catch (IOException e) {
                Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }

    public List<Item> getAll() {
        List<Item> items = new ArrayList<>();
        try (Scanner scanner = new Scanner(new FileInputStream(FILE_PATH))) {
            while (scanner.hasNextLine()) {
                String itemLine = scanner.nextLine().trim(); // Trim to avoid trailing spaces
                if (!itemLine.isEmpty()) { // Skip empty lines
                    String[] itemInfo = itemLine.split(",");
                    Item item = new Item(itemInfo[0],
                            Double.parseDouble(itemInfo[1]),
                            Integer.parseInt(itemInfo[2]));
                    items.add(item);
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return items;
    }

    public Item getItemByIndex(int index) {
        List<Item> listOfItems = getAll();
        // Use 0-based indexing
        if (index >= 0 && index < listOfItems.size()) {
            return listOfItems.get(index);
        }
        return null;
    }


    public void create(Item item) {
        try (PrintWriter pw = new PrintWriter(new FileOutputStream(FILE_PATH, true))) {
            pw.println(item.getName() + "," + String.format("%.1f", item.getPrice()) + "," + item.getQuantity());
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public synchronized boolean delete(String name) {
        List<Item> itemList = getAll();
        boolean found = itemList.removeIf(item -> item.getName().equalsIgnoreCase(name));
        if (found) {
            saveAll(itemList);
        }
        return found;
    }

    public synchronized boolean update(String srcName, Item updatedItem) {
        List<Item> itemList = getAll();
        boolean updated = false;
        for (int i = 0; i < itemList.size(); i++) {
            if (itemList.get(i).getName().equalsIgnoreCase(srcName)) {
                itemList.set(i, updatedItem);
                updated = true;
                break;
            }
        }
        if (updated) {
            saveAll(itemList);
        }
        return updated;
    }

    public synchronized void reduceItemQuantityByItemName(String itemName, int reduceNumber) {
        List<Item> itemList = getAll();
        for (int i = 0; i < itemList.size(); i++) {
            Item item = itemList.get(i);
            if (item.getName().equalsIgnoreCase(itemName)) {
                item.setQuantity(Math.max(0, item.getQuantity() - reduceNumber));
                itemList.set(i, item);
            }
        }
        saveAll(itemList);
    }

    private void saveAll(List<Item> itemList) {
        try (PrintWriter pw = new PrintWriter(new FileOutputStream(FILE_PATH))) {
            itemList.forEach(item -> pw.println(
                    item.getName() + "," + String.format("%.1f", item.getPrice()) + "," + item.getQuantity()));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void clearAll() {
        try {
            Files.deleteIfExists(Paths.get(FILE_PATH));
            new File(FILE_PATH).createNewFile(); // Recreate an empty file
        } catch (IOException ex) {
            Logger.getLogger(ItemService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
