package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class AddItemTest {

    private AddItem addItem;

    @Before
    public void setUp() {
        addItem = new AddItem();
        addItem.setVisible(true);
    }

    @Test
    public void testAddButtonActionPerformedWithValidInput() {
        // Set valid input values
        addItem.getItemNameField().setText("Pizza");
        addItem.getItemPriceField().setText("12.5");
        addItem.getItemQuantityField().setText("5");

        // Simulate the add button click
        addItem.getAddButton().doClick();

        // Assert that fields are cleared after adding
        assertEquals("Item name field should be cleared after adding", "", addItem.getItemNameField().getText());
        assertEquals("Item price field should be cleared after adding", "", addItem.getItemPriceField().getText());
        assertEquals("Item quantity field should be cleared after adding", "", addItem.getItemQuantityField().getText());
    }


    @Test
    public void testAddButtonActionPerformedWithEmptyName() {
        // Set input values with an empty name
        addItem.getItemNameField().setText("");
        addItem.getItemPriceField().setText("12.5");
        addItem.getItemQuantityField().setText("5");

        // Simulate the add button click
        addItem.getAddButton().doClick();

        // Assert that the fields remain unchanged and the appropriate message is shown
        assertEquals("Item name field should remain unchanged", "", addItem.getItemNameField().getText());
    }

    @Test
    public void testAddButtonActionPerformedWithInvalidPrice() {
        // Set input values with an invalid price
        addItem.getItemNameField().setText("Pizza");
        addItem.getItemPriceField().setText("-10");
        addItem.getItemQuantityField().setText("5");

        // Simulate the add button click
        addItem.getAddButton().doClick();

        // Assert that fields remain unchanged and an error message is shown
        assertEquals("Item price field should remain unchanged", "-10", addItem.getItemPriceField().getText());
    }

    @Test
    public void testAddButtonActionPerformedWithInvalidQuantity() {
        // Set input values with an invalid quantity
        addItem.getItemNameField().setText("Pizza");
        addItem.getItemPriceField().setText("12.5");
        addItem.getItemQuantityField().setText("-3");

        // Simulate the add button click
        addItem.getAddButton().doClick();

        // Assert that fields remain unchanged and an error message is shown
        assertEquals("Item quantity field should remain unchanged", "-3", addItem.getItemQuantityField().getText());
    }

    @Test
    public void testBackButtonActionPerformed() {
        // Simulate the back button click
        addItem.getBackButton().doClick();

        // Assert that the AddItem frame is closed
        assertFalse("AddItem frame should not be visible after clicking Back", addItem.isVisible());
    }
}
