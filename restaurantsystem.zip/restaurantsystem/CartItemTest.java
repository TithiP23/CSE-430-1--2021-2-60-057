package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CartItemTest {

    private CartItem cartItem;
    private Item item;

    @Before
    public void setUp() {
        // Initialize an Item
        item = new Item("Apple", 1.5, 10);

        // Create a CartItem with initial values
        cartItem = new CartItem(item, 5, 7.5);
    }

    @Test
    public void testGetItem() {
        // Validate the item associated with the CartItem
        assertEquals("Item should match the initialized item", item, cartItem.getItem());
    }

    @Test
    public void testSetItem() {
        // Create a new Item
        Item newItem = new Item("Banana", 0.8, 20);

        // Update the CartItem's item
        cartItem.setItem(newItem);

        // Validate the updated item
        assertEquals("Item should be updated to the new item", newItem, cartItem.getItem());
    }

    @Test
    public void testGetQuantity() {
        // Validate the initial quantity
        assertEquals("Quantity should match the initialized value", 5, cartItem.getQuantity());
    }

    @Test
    public void testSetQuantity() {
        // Update the quantity
        cartItem.setQuantity(3);

        // Validate the updated quantity
        assertEquals("Quantity should be updated to the new value", 3, cartItem.getQuantity());
    }

    @Test
    public void testGetPrice() {
        // Validate the initial price
        assertEquals("Price should match the initialized value", 7.5, cartItem.getPrice(), 0.01);
    }

    @Test
    public void testSetPrice() {
        // Update the price
        cartItem.setPrice(4.0);

        // Validate the updated price
        assertEquals("Price should be updated to the new value", 4.0, cartItem.getPrice(), 0.01);
    }

    @Test
    public void testItemAssociation() {
        // Validate that the CartItem is associated with the correct item details
        assertEquals("Item name should be Apple", "Apple", cartItem.getItem().getName());
        assertEquals("Item price should be 1.5", 1.5, cartItem.getItem().getPrice(), 0.01);
        assertEquals("Item quantity should be 10", 10, cartItem.getItem().getQuantity());
    }
}
