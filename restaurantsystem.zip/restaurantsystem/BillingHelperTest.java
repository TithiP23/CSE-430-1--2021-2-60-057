package restaurantsystem;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class BillingHelperTest {

    private BillingHelper billingHelper;

    @Before
    public void setUp() throws Exception {
        // Set up the test environment with a mock order.txt file
        File storageDir = new File("storage");
        if (!storageDir.exists()) {
            storageDir.mkdirs();
        }

        try (PrintWriter writer = new PrintWriter(new FileOutputStream("storage/order.txt"))) {
            writer.println("Apple");
            writer.println("3");
            writer.println("4.5");
            writer.println("Banana");
            writer.println("5");
            writer.println("4.0");
        }

        billingHelper = new BillingHelper();
    }

    @After
    public void tearDown() throws Exception {
        // Clean up the test environment by deleting the mock order.txt file
        File orderFile = new File("storage/order.txt");
        if (orderFile.exists()) {
            orderFile.delete();
        }
    }

    @Test
    public void testGetFullNames() {
        StringBuilder expectedOutput = new StringBuilder();
        expectedOutput.append("Apple \t3\t4.5\n");
        expectedOutput.append("Banana \t5\t4.0\n");

        assertEquals("Full names output should match", expectedOutput.toString(), billingHelper.getFullNames().toString());
    }

    @Test
    public void testGetTotal() {
        String expectedTotal = "Total Price is : 8.5";
        assertEquals("Total price calculation should match", expectedTotal, billingHelper.getTotal());
    }

    @Test
    public void testFileNotFound() {
        // Remove the order.txt file to simulate a file not found scenario
        File orderFile = new File("storage/order.txt");
        if (orderFile.exists()) {
            orderFile.delete();
        }

        BillingHelper helperWithoutFile = new BillingHelper();
        assertEquals("When file is not found, full names should be empty", "", helperWithoutFile.getFullNames().toString());
        assertEquals("When file is not found, total price should be 0", "Total Price is : 0.0", helperWithoutFile.getTotal());
    }
}
