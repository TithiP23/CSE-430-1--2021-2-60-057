package restaurantsystem;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class LabourTest {

    private Labour labour;

    @Before
    public void setUp() {
        // Initialize the Labour object before each test
        labour = new Labour("1", "John Doe", 5000.0);
    }

    @Test
    public void testConstructor() {
        // Test if the constructor initializes the fields correctly
        assertEquals("ID should be '1'", "1", labour.getId());
        assertEquals("Name should be 'John Doe'", "John Doe", labour.getName());
        assertEquals("Salary should be 5000.0", 5000.0, labour.getSalary(), 0.0);
    }

    @Test
    public void testSetId() {
        // Test setting a new ID
        labour.setId("2");
        assertEquals("ID should be updated to '2'", "2", labour.getId());
    }

    @Test
    public void testSetName() {
        // Test setting a new name
        labour.setName("Jane Doe");
        assertEquals("Name should be updated to 'Jane Doe'", "Jane Doe", labour.getName());
    }

    @Test
    public void testSetSalary() {
        // Test setting a new salary
        labour.setSalary(6000.0);
        assertEquals("Salary should be updated to 6000.0", 6000.0, labour.getSalary(), 0.0);
    }

    @Test
    public void testNegativeSalary() {
        // Test setting a negative salary
        labour.setSalary(-1000.0);
        assertEquals("Salary should allow negative values", -1000.0, labour.getSalary(), 0.0);
    }

    @Test
    public void testZeroSalary() {
        // Test setting the salary to zero
        labour.setSalary(0.0);
        assertEquals("Salary should be updated to 0.0", 0.0, labour.getSalary(), 0.0);
    }
}
