package restaurantsystem;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LabourService {

    private static final String LABOUR_FILE_PATH = "storage/labour.txt";

    public LabourService() {
        ensureFileExists();
    }

    private void ensureFileExists() {
        try {
            Files.createDirectories(Paths.get("storage"));
            if (!Files.exists(Paths.get(LABOUR_FILE_PATH))) {
                Files.createFile(Paths.get(LABOUR_FILE_PATH));
            }
        } catch (IOException e) {
            Logger.getLogger(LabourService.class.getName()).log(Level.SEVERE, "Error ensuring file exists", e);
        }
    }

    public List<Labour> getAll() {
        List<Labour> labourList = new ArrayList<>();
        try (Scanner scanner = new Scanner(new FileInputStream(LABOUR_FILE_PATH))) {
            while (scanner.hasNextLine()) {
                String labourLine = scanner.nextLine();
                String[] labourInfo = labourLine.split(",");
                if (labourInfo.length == 3) {
                    Labour labour = new Labour(labourInfo[0], labourInfo[1], Double.parseDouble(labourInfo[2]));
                    labourList.add(labour);
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(LabourService.class.getName()).log(Level.SEVERE, "File not found", ex);
        }
        return labourList;
    }

    public void create(Labour labour) {
        try (PrintWriter pw = new PrintWriter(new FileOutputStream(LABOUR_FILE_PATH, true))) {
            pw.println(labour.getId() + "," + labour.getName() + "," + labour.getSalary());
        } catch (FileNotFoundException ex) {
            Logger.getLogger(LabourService.class.getName()).log(Level.SEVERE, "Error writing to file", ex);
        }
    }

    public synchronized boolean update(String sourceId, Labour updatedLabour) {
        List<Labour> labourList = getAll();
        boolean updated = false;

        for (int i = 0; i < labourList.size(); i++) {
            Labour labour = labourList.get(i);
            if (labour.getId().equalsIgnoreCase(sourceId)) {
                labourList.set(i, updatedLabour);
                updated = true;
                break;
            }
        }

        if (updated) {
            rewriteFile(labourList);
        }
        return updated;
    }

    public synchronized void delete(String labourID) {
        List<Labour> labourList = getAll();

        if (labourList.removeIf(labour -> labour.getId().equalsIgnoreCase(labourID))) {
            rewriteFile(labourList);
        }
    }

    private void rewriteFile(List<Labour> labourList) {
        try (PrintWriter pw = new PrintWriter(new FileOutputStream(LABOUR_FILE_PATH))) {
            labourList.forEach(labour -> pw.println(labour.getId() + "," + labour.getName() + "," + labour.getSalary()));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(LabourService.class.getName()).log(Level.SEVERE, "Error rewriting file", ex);
        }
    }
}
