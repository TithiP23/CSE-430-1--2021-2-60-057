package restaurantsystem;

import javax.swing.JOptionPane;

/**
 *
 * @author Shahin
 */
@SuppressWarnings("serial")
public class UpdateItem extends javax.swing.JFrame {

    private final ItemService itemService;

    // UI Components
    private javax.swing.JTextArea text;
    private javax.swing.JTextField modText;
    private javax.swing.JTextField mName;
    private javax.swing.JTextField mPrice;
    private javax.swing.JTextField mQuantity;
    private javax.swing.JButton updateButton;
    private javax.swing.JButton backButton;

    /**
     * Creates new form UpdateItem
     */
    public UpdateItem() {
        initComponents();
        this.itemService = new ItemService();
        performFileRelatedTask();
    }

    /**
     * Updates the text area with current items from the file.
     */
    void performFileRelatedTask() {
        StringBuilder fullnames = new StringBuilder();

        itemService.getAll().forEach((item) -> {
            fullnames.append(item.getName())
                    .append("\t")
                    .append(item.getPrice())
                    .append("\t")
                    .append(item.getQuantity())
                    .append("\n");
        });

        text.setText(fullnames.toString());
    }

    // Public getter methods for test interaction
    public javax.swing.JTextField getModTextField() {
        return modText;
    }

    public javax.swing.JTextField getMNameField() {
        return mName;
    }

    public javax.swing.JTextField getMPriceField() {
        return mPrice;
    }

    public javax.swing.JTextField getMQuantityField() {
        return mQuantity;
    }

    public javax.swing.JTextArea getTextArea() {
        return text;
    }

    public javax.swing.JButton getUpdateButton() {
        return updateButton;
    }

    public javax.swing.JButton getBackButton() {
        return backButton;
    }


    private void initComponents() {
        // Initialize components
        text = new javax.swing.JTextArea();
        modText = new javax.swing.JTextField();
        mName = new javax.swing.JTextField();
        mPrice = new javax.swing.JTextField();
        mQuantity = new javax.swing.JTextField();
        updateButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();

        javax.swing.JLabel jLabel1 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel2 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel3 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel4 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel5 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel6 = new javax.swing.JLabel();
        javax.swing.JLabel jLabel7 = new javax.swing.JLabel();
        javax.swing.JScrollPane jScrollPane1 = new javax.swing.JScrollPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        text.setEditable(false);
        text.setColumns(20);
        text.setRows(5);
        jScrollPane1.setViewportView(text);

        jLabel1.setText("Enter item name to update information");
        jLabel2.setText("Enter New Name");
        jLabel3.setText("Enter New Price");
        jLabel4.setText("Enter New Quantity");
        jLabel5.setText("Name");
        jLabel6.setText("Quantity");
        jLabel7.setText("Price");

        updateButton.setText("Update");
        updateButton.addActionListener(evt -> updateButtonActionPerformed(evt));

        backButton.setText("Back");
        backButton.addActionListener(evt -> backButtonActionPerformed(evt));

        // Layout setup
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel7)
                        .addGap(66, 66, 66)
                        .addComponent(jLabel6)
                        .addGap(48, 48, 48))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(backButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(updateButton))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 338, Short.MAX_VALUE)
                        .addGap(40, 40, 40)
                        .addComponent(mName, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(modText)
                            .addComponent(mPrice)
                            .addComponent(mQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6))
                .addGap(3, 3, 3)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(modText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(mQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backButton)
                    .addComponent(updateButton))
                .addGap(47, 47, 47))
        );

        pack();
        setLocationRelativeTo(null);
    }
    
    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {
        ItemManagement im = new ItemManagement();
        im.setVisible(true);
        this.setVisible(false);
    }


    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        String srcName = modText.getText();
        String modName = mName.getText();
        String modPrice = mPrice.getText();
        String modQuantity = mQuantity.getText();

        if (srcName.isEmpty() || modName.isEmpty() || modPrice.isEmpty() || modQuantity.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Field(s) cannot be left empty");
            return;
        }

        if (!modPrice.matches("\\d+(\\.\\d+)?") || Double.parseDouble(modPrice) <= 0) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price for the item");
            return;
        }

        if (!modQuantity.matches("\\d+") || Integer.parseInt(modQuantity) <= 0) {
            JOptionPane.showMessageDialog(this, "Please enter a valid quantity for the item");
            return;
        }

        Item updatedItem = new Item(modName, Double.parseDouble(modPrice), Integer.parseInt(modQuantity));

        boolean isUpdated = itemService.update(srcName, updatedItem);

        if (!isUpdated) {
            JOptionPane.showMessageDialog(this, "No item name was found to update.");
            return;
        }

        // Reset the modify fields
        modText.setText("");
        mName.setText("");
        mPrice.setText("");
        mQuantity.setText("");

        // Show confirmation pop-up
        JOptionPane.showMessageDialog(this, "Item has been Modified");

        // Update display information
        performFileRelatedTask();
    }//GEN-LAST:event_updateButtonActionPerformed

}

