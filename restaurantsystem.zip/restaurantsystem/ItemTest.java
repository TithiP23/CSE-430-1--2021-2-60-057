package restaurantsystem;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ItemTest {

    private Item item;

    @Before
    public void setUp() {
        // Initialize the Item object before each test
        item = new Item("Pizza", 12.5, 10);
    }

    @Test
    public void testConstructorAndGetters() {
        // Test the constructor and getter methods
        assertEquals("Pizza", item.getName());
        assertEquals(12.5, item.getPrice(), 0.01);
        assertEquals(10, item.getQuantity());
    }

    @Test
    public void testSetName() {
        // Test the setName method
        item.setName("Burger");
        assertEquals("Burger", item.getName());
    }

    @Test
    public void testSetPrice() {
        // Test the setPrice method
        item.setPrice(15.0);
        assertEquals(15.0, item.getPrice(), 0.01);
    }

    @Test
    public void testSetQuantity() {
        // Test the setQuantity method
        item.setQuantity(20);
        assertEquals(20, item.getQuantity());
    }

    @Test
    public void testNegativePrice() {
        // Test setting a negative price
        item.setPrice(-10.0);
        assertEquals("Negative price should be set correctly", -10.0, item.getPrice(), 0.01);
    }

    @Test
    public void testZeroQuantity() {
        // Test setting the quantity to zero
        item.setQuantity(0);
        assertEquals("Quantity should be zero", 0, item.getQuantity());
    }
}

