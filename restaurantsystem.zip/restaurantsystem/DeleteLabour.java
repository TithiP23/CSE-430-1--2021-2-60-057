package restaurantsystem;

import javax.swing.*;

@SuppressWarnings("serial")
public class DeleteLabour extends javax.swing.JFrame {

    private final LabourService labourService;

    public DeleteLabour() {
        initComponents();
        this.labourService = new LabourService();
        performFileRelatedTask();
    }

    void performFileRelatedTask() {
        StringBuilder stringBuilder = new StringBuilder();
        labourService.getAll().forEach((labour) -> {
            stringBuilder.append(labour.getId())
                         .append("\t")
                         .append(labour.getName())
                         .append("\t")
                         .append(labour.getSalary())
                         .append("\n");
        });
        text.setText(stringBuilder.toString());
    }

    public JTextField getLabourIDField() {
        return labourIDField;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public JButton getBackButton() {
        return backButton;
    }

    public JTextArea getTextArea() {
        return text;
    }

    private void initComponents() {
        deleteButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        text = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        labourIDField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        deleteButton.setText("Delete");
        deleteButton.addActionListener(evt -> deleteButtonActionPerformed(evt));

        backButton.setText("Back");
        backButton.addActionListener(evt -> backButtonActionPerformed(evt));

        text.setEditable(false);
        text.setColumns(20);
        text.setRows(5);
        jScrollPane1.setViewportView(text);

        jLabel1.setText("Which Labour ID do you want to delete?");

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addGap(20)
                .addComponent(jLabel1)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labourIDField, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
                .addGap(18)
                .addComponent(deleteButton)
                .addGap(18)
                .addComponent(backButton)
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20)
                .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
                .addGap(18)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(labourIDField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteButton)
                    .addComponent(backButton))
                .addGap(20))
        );

        pack();
    }

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {
        String deleteLabourID = labourIDField.getText();

        if (deleteLabourID.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a valid ID to delete.");
            return;
        }

        labourService.delete(deleteLabourID);
        JOptionPane.showMessageDialog(this, "Labour has been deleted.");

        labourIDField.setText("");
        performFileRelatedTask();
    }

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {
        new LabourManagement().setVisible(true);
        this.setVisible(false);
    }

    private javax.swing.JButton backButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JTextArea text;
    private javax.swing.JTextField labourIDField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
}
