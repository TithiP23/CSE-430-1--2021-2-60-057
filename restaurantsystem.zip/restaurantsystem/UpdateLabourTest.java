package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class UpdateLabourTest {

    private UpdateLabour updateLabour;

    @Before
    public void setUp() {
        // Clear the labour storage file before each test
        try (PrintWriter pw = new PrintWriter("storage/labour.txt")) {
            pw.print(""); // Clear content
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Initialize the UpdateLabour form
        updateLabour = new UpdateLabour();
        updateLabour.setVisible(true);
    }

    @Test
    public void testUpdateButtonActionPerformedWithValidInput() {
        LabourService labourService = new LabourService();
        // Add a labour entry to update
        labourService.create(new Labour("1", "Alice", 3000.0));

        // Set valid input values
        updateLabour.getOldLabourIdField().setText("1");
        updateLabour.getNewLabourIDField().setText("2");
        updateLabour.getNewLabourNameField().setText("Bob");
        updateLabour.getNewLabourSalaryField().setText("4000");

        // Simulate update button click
        updateLabour.getUpdateButton().doClick();

        // Assert that the fields are cleared
        assertEquals("", updateLabour.getOldLabourIdField().getText());
        assertEquals("", updateLabour.getNewLabourIDField().getText());
        assertEquals("", updateLabour.getNewLabourNameField().getText());
        assertEquals("", updateLabour.getNewLabourSalaryField().getText());

        // Assert that the updated entry exists in the labour service
        Labour updatedLabour = labourService.getAll().stream().filter(l -> l.getId().equals("2")).findFirst().orElse(null);
        assertNotNull("Updated labour entry should exist", updatedLabour);
        assertEquals("Bob", updatedLabour.getName());
        assertEquals(4000.0, updatedLabour.getSalary(), 0.01);
    }

    @Test
    public void testUpdateButtonActionPerformedWithEmptyFields() {
        // Set empty input values
        updateLabour.getOldLabourIdField().setText("");
        updateLabour.getNewLabourIDField().setText("");
        updateLabour.getNewLabourNameField().setText("");
        updateLabour.getNewLabourSalaryField().setText("");

        // Simulate update button click
        updateLabour.getUpdateButton().doClick();

        // Assert that fields remain empty
        assertEquals("", updateLabour.getOldLabourIdField().getText());
        assertEquals("", updateLabour.getNewLabourIDField().getText());
        assertEquals("", updateLabour.getNewLabourNameField().getText());
        assertEquals("", updateLabour.getNewLabourSalaryField().getText());
    }

    @Test
    public void testUpdateButtonActionPerformedWithNonexistentID() {
        // Set input for a non-existent labour ID
        updateLabour.getOldLabourIdField().setText("999");
        updateLabour.getNewLabourIDField().setText("2");
        updateLabour.getNewLabourNameField().setText("Bob");
        updateLabour.getNewLabourSalaryField().setText("4000");

        // Simulate update button click
        updateLabour.getUpdateButton().doClick();

        // Assert that fields are cleared
        assertEquals("", updateLabour.getOldLabourIdField().getText());
        assertEquals("", updateLabour.getNewLabourIDField().getText());
        assertEquals("", updateLabour.getNewLabourNameField().getText());
        assertEquals("", updateLabour.getNewLabourSalaryField().getText());
    }

    @Test
    public void testBackButtonActionPerformed() {
        // Simulate the back button click
        updateLabour.getBackButton().doClick();

        // Assert that the UpdateLabour frame is closed
        assertFalse("UpdateLabour frame should not be visible after clicking Back", updateLabour.isVisible());
    }

    @Test
    public void testPerformFileRelatedTask() {
        LabourService labourService = new LabourService();
        // Add labour entries for testing
        labourService.create(new Labour("1", "Alice", 3000.0));
        labourService.create(new Labour("2", "Bob", 4000.0));

        // Refresh the text area
        updateLabour.performFileRelatedTask();

        // Assert the text area content
        String expectedText = "1\tAlice\t3000.0\n2\tBob\t4000.0\n";
        String actualText = updateLabour.getTextArea().getText();
        assertEquals("Text area should contain labour data", expectedText, actualText);
    }
}
