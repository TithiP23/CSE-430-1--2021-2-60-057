package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ViewItemTest {

    private ViewItem viewItem;
    private ItemService itemService;

    @Before
    public void setUp() {
        // Set up the ItemService with test data
        itemService = new ItemService();
        itemService.clearAll(); // Clear the storage file for consistent tests
        itemService.create(new Item("Apple", 1.5, 10));
        itemService.create(new Item("Banana", 0.8, 20));

        // Initialize the ViewItem frame
        viewItem = new ViewItem();
        viewItem.setVisible(true);
    }

    @Test
    public void testPerformFileRelatedTask() {
        // Expected content
        String expectedContent = "Apple\t1.5\t10\n" +
                                 "Banana\t0.8\t20";

        // Assert that the content of the text area matches the expected content
        assertEquals("The text area should display the correct item details",
                     expectedContent, viewItem.getTextArea().getText().trim());
    }

    @Test
    public void testBackButtonActionPerformed() {
        // Simulate the back button click
        viewItem.getBackButton().doClick();

        // Assert that the ViewItem frame is closed
        assertFalse("ViewItem frame should not be visible after clicking Back", viewItem.isVisible());

        // Assert that the ItemManagement frame is displayed
        ItemManagement itemManagement = new ItemManagement();
        itemManagement.setVisible(true); // Ensure visibility for test
        assertTrue("ItemManagement frame should be visible", itemManagement.isVisible());
        itemManagement.dispose();
    }

    @Test
    public void testDisplayWithoutItems() {
        // Clear all items in the ItemService
        itemService.clearAll();

        // Refresh the ViewItem's text area
        viewItem.performFileRelatedTask();

        // Assert that the text area is empty
        assertEquals("The text area should be empty when no items are available", "", viewItem.getTextArea().getText().trim());
    }
}
