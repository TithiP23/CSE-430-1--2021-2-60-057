package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

import static org.junit.Assert.*;

public class UpdateItemTest {

    private UpdateItem updateItem;
    private ItemService itemService;

    @Before
    public void setUp() {
        // Clear the item storage file before each test
        try (PrintWriter pw = new PrintWriter("storage/item.txt")) {
            pw.print("");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        itemService = new ItemService();
        updateItem = new UpdateItem();
        updateItem.setVisible(true);
    }

    @Test
    public void testUpdateButtonActionPerformedWithValidInput() {
        // Add an item to update
        itemService.create(new Item("Apple", 1.5, 10));

        // Set valid input values
        updateItem.getModTextField().setText("Apple");
        updateItem.getMNameField().setText("Banana");
        updateItem.getMPriceField().setText("2.0");
        updateItem.getMQuantityField().setText("15");

        // Simulate update button click
        updateItem.getUpdateButton().doClick();

        // Assert that the fields are cleared
        assertEquals("", updateItem.getModTextField().getText());
        assertEquals("", updateItem.getMNameField().getText());
        assertEquals("", updateItem.getMPriceField().getText());
        assertEquals("", updateItem.getMQuantityField().getText());

        // Assert that the item was updated
        Item updatedItem = itemService.getAll().stream()
                .filter(item -> item.getName().equals("Banana"))
                .findFirst()
                .orElse(null);
        assertNotNull("Updated item should exist", updatedItem);
        assertEquals(2.0, updatedItem.getPrice(), 0.01);
        assertEquals(15, updatedItem.getQuantity());
    }


    @Test
    public void testUpdateButtonActionPerformedWithEmptyFields() {
        // Set empty input values
        updateItem.getModTextField().setText("");
        updateItem.getMNameField().setText("");
        updateItem.getMPriceField().setText("");
        updateItem.getMQuantityField().setText("");

        // Simulate update button click
        updateItem.getUpdateButton().doClick();

        // Assert that fields remain empty
        assertEquals("", updateItem.getModTextField().getText());
        assertEquals("", updateItem.getMNameField().getText());
        assertEquals("", updateItem.getMPriceField().getText());
        assertEquals("", updateItem.getMQuantityField().getText());
    }

    @Test
    public void testUpdateButtonActionPerformedWithInvalidPrice() {
        // Add an item to update
        itemService.create(new Item("Apple", 1.5, 10));

        // Set invalid price input
        updateItem.getModTextField().setText("Apple");
        updateItem.getMNameField().setText("Banana");
        updateItem.getMPriceField().setText("-5");
        updateItem.getMQuantityField().setText("15");

        // Simulate update button click
        updateItem.getUpdateButton().doClick();

        // Assert that the item was not updated
        Item item = itemService.getAll().stream()
                .filter(i -> i.getName().equals("Apple"))
                .findFirst()
                .orElse(null);
        assertNotNull("Original item should still exist", item);
        assertEquals(1.5, item.getPrice(), 0.01);
    }

    @Test
    public void testBackButtonActionPerformed() {
        // Simulate the back button click
        updateItem.getBackButton().doClick();

        // Assert that the UpdateItem frame is closed
        assertFalse("UpdateItem frame should not be visible after clicking Back", updateItem.isVisible());

        // Assert that the ItemManagement frame is visible
        ItemManagement itemManagement = new ItemManagement();
        itemManagement.setVisible(true);
        assertTrue("ItemManagement frame should be visible", itemManagement.isVisible());
        itemManagement.dispose();
    }

    @Test
    public void testPerformFileRelatedTask() {
        // Add items for testing
        itemService.create(new Item("Apple", 1.5, 10));
        itemService.create(new Item("Banana", 2.0, 20));

        // Perform file-related task to refresh the text area
        updateItem.performFileRelatedTask();

        // Assert the text area content
        String expectedText = "Apple\t1.5\t10\nBanana\t2.0\t20\n";
        assertEquals("Text area should display all items", expectedText, updateItem.getTextArea().getText());
    }
}
