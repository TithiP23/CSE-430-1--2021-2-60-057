package restaurantsystem;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static void main(String[] args) {
        createRequiredFileIfDoesNotExist();

        // Simulate showing the login page
        Login login = new Login();
        login.setVisible(true);
    }

    /**
     * Public method to create required files if they do not exist.
     * Ensures the storage directory and necessary files are created.
     */
    public static void createRequiredFileIfDoesNotExist() {
        String[] fileNames = {
            "storage/item.txt",
            "storage/labour.txt",
            "storage/order.txt",
            "storage/orderLine.txt"
        };

        File rootDir = new File("storage");
        if (!rootDir.exists()) {
            rootDir.mkdirs();
        }

        for (String fileName : fileNames) {
            File file = new File(fileName);
            if (!file.exists()) {
                try {
                    file.createNewFile();
                } catch (IOException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, "Error creating file: " + fileName, ex);
                }
            }
        }
    }
}
