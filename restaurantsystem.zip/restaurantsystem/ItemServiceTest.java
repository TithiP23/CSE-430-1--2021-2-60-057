package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

import static org.junit.Assert.*;

public class ItemServiceTest {

    private ItemService itemService;

    @Before
    public void setUp() {
        itemService = new ItemService();
        // Clear the storage file before each test
        try (PrintWriter pw = new PrintWriter("storage/item.txt")) {
            pw.print("");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testCreateAndGetAll() {
        // Create some items
        Item item1 = new Item("Apple", 1.5, 10);
        Item item2 = new Item("Banana", 0.8, 20);

        itemService.create(item1);
        itemService.create(item2);

        // Get all items
        List<Item> items = itemService.getAll();

        // Assert the size and content
        assertEquals(2, items.size());
        assertEquals("Apple", items.get(0).getName());
        assertEquals(1.5, items.get(0).getPrice(), 0.01);
        assertEquals(10, items.get(0).getQuantity());
        assertEquals("Banana", items.get(1).getName());
        assertEquals(0.8, items.get(1).getPrice(), 0.01);
        assertEquals(20, items.get(1).getQuantity());
    }

    @Test
    public void testGetItemByIndex() {
        // Create some items
        Item item1 = new Item("Apple", 1.5, 10);
        Item item2 = new Item("Banana", 0.8, 20);

        itemService.create(item1);
        itemService.create(item2);

        // Get item by index
        Item retrievedItem = itemService.getItemByIndex(1);

        // Assert the content
        assertNotNull(retrievedItem);
        assertEquals("Apple", retrievedItem.getName());
        assertEquals(1.5, retrievedItem.getPrice(), 0.01);
        assertEquals(10, retrievedItem.getQuantity());

        // Test with an invalid index
        assertNull(itemService.getItemByIndex(3));
    }

    @Test
    public void testDelete() {
        // Create some items
        Item item1 = new Item("Apple", 1.5, 10);
        Item item2 = new Item("Banana", 0.8, 20);

        itemService.create(item1);
        itemService.create(item2);

        // Delete an item
        boolean isDeleted = itemService.delete("Apple");

        // Assert the deletion
        assertTrue(isDeleted);
        List<Item> items = itemService.getAll();
        assertEquals(1, items.size());
        assertEquals("Banana", items.get(0).getName());

        // Test deletion of a non-existent item
        assertFalse(itemService.delete("Grapes"));
    }

    @Test
    public void testUpdate() {
        // Create an item
        Item item1 = new Item("Apple", 1.5, 10);
        itemService.create(item1);

        // Update the item
        Item updatedItem = new Item("Green Apple", 2.0, 15);
        boolean isUpdated = itemService.update("Apple", updatedItem);

        // Assert the update
        assertTrue(isUpdated);
        List<Item> items = itemService.getAll();
        assertEquals(1, items.size());
        assertEquals("Green Apple", items.get(0).getName());
        assertEquals(2.0, items.get(0).getPrice(), 0.01);
        assertEquals(15, items.get(0).getQuantity());

        // Test update of a non-existent item
        assertFalse(itemService.update("Banana", updatedItem));
    }

    @Test
    public void testReduceItemQuantityByItemName() {
        // Create an item
        Item item1 = new Item("Apple", 1.5, 10);
        itemService.create(item1);

        // Reduce the quantity
        itemService.reduceItemQuantityByItemName("Apple", 5);

        // Assert the reduced quantity
        List<Item> items = itemService.getAll();
        assertEquals(1, items.size());
        assertEquals(5, items.get(0).getQuantity());

        // Reduce the quantity beyond 0
        itemService.reduceItemQuantityByItemName("Apple", 10);
        items = itemService.getAll();
        assertEquals(0, items.get(0).getQuantity());
    }
}
