package restaurantsystem;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.swing.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class BillingManagementTest {

    private BillingManagement billingManagement;

    @Before
    public void setUp() throws Exception {
        // Set up test environment
        File storageDir = new File("storage");
        if (!storageDir.exists()) {
            storageDir.mkdirs();
        }

        // Create a mock order.txt file
        try (PrintWriter writer = new PrintWriter(new FileOutputStream("storage/order.txt"))) {
            writer.println("Apple");
            writer.println("3");
            writer.println("4.5");
            writer.println("Banana");
            writer.println("5");
            writer.println("4.0");
        }

        billingManagement = new BillingManagement();
        billingManagement.display();
    }

    @After
    public void tearDown() throws Exception {
        // Clean up test environment
        File orderFile = new File("storage/order.txt");
        if (orderFile.exists()) {
            orderFile.delete();
        }
    }

    @Test
    public void testDisplay() {
        // Validate that billing information is displayed correctly
        String expectedText = "Apple \t3\t4.5\nBanana \t5\t4.0\n";
        assertEquals("Billing information should match", expectedText.trim(), billingManagement.text.getText().trim());

        String expectedTotal = "Total Price is : 8.5";
        assertEquals("Total price should match", expectedTotal, billingManagement.totalPriceArea.getText());
    }

    @Test
    public void testPaymentButtonActionPerformed() {
        // Simulate clicking the payment button
        billingManagement.paymentButton.doClick();

        // Validate that files are cleared after payment
        File tempFile = new File("temp.txt");
        File orderFile = new File("storage/order.txt");
        File totalBillFile = new File("totalBill.txt");

        assertTrue("Temp file should exist after payment", tempFile.exists());
        assertTrue("Total bill file should exist after payment", totalBillFile.exists());
        assertEquals("Order file should be empty after payment", 0, orderFile.length());

        // Clean up
        tempFile.delete();
        totalBillFile.delete();
    }

    @Test
    public void testPrintReceiptButtonActionPerformed() {
        // Mock the print process
        JTextArea mockTextArea = billingManagement.text;

        try {
            boolean complete = mockTextArea.print();
            assertTrue("Receipt printing should complete successfully", complete);
        } catch (Exception e) {
            fail("Printing failed with exception: " + e.getMessage());
        }
    }

    @Test
    public void testBackButtonActionPerformed() {
        // Simulate clicking the back button
        billingManagement.backButton.doClick();

        // Validate that the BillingManagement window is closed
        assertFalse("BillingManagement window should be closed", billingManagement.isVisible());
    }
}
