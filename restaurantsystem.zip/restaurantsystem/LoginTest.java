package restaurantsystem;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class LoginTest {

    private Login login;

    @Before
    public void setUp() {
        login = new Login();
        login.setVisible(true);
    }

    @Test
    public void testDefaultUserNameAndPassword() {
        assertEquals("Default username should be 'shahin'", "shahin", login.userNameField.getText());
        assertEquals("Default password should be 'shahin'", "shahin", new String(login.passwordField.getPassword()));
    }

    @Test
    public void testSuccessfulLogin() {
        login.userNameField.setText("shahin");
        login.passwordField.setText("shahin");
        login.loginButton.doClick(); // Simulate button click

        assertFalse("Login frame should be closed after successful login", login.isVisible());
    }

    @Test
    public void testFailedLogin() {
        login.userNameField.setText("wrongUser");
        login.passwordField.setText("wrongPassword");
        login.loginButton.doClick(); // Simulate button click

        assertEquals("Username field should be cleared after failed login", "", login.userNameField.getText());
        assertEquals("Password field should be cleared after failed login", "", new String(login.passwordField.getPassword()));
        assertTrue("Login frame should remain visible after failed login", login.isVisible());
    }

    @Test
    public void testEmptyLogin() {
        login.userNameField.setText("");
        login.passwordField.setText("");
        login.loginButton.doClick(); // Simulate button click

        assertEquals("Username field should remain empty", "", login.userNameField.getText());
        assertEquals("Password field should remain empty", "", new String(login.passwordField.getPassword()));
        assertTrue("Login frame should remain visible after failed login", login.isVisible());
    }
}

