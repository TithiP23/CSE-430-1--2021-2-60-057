package restaurantsystem;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import static org.junit.Assert.*;

public class LabourServiceTest {

    private LabourService labourService;
    private final String testFilePath = "storage/labour.txt";

    @Before
    public void setUp() throws IOException {
        // Initialize the LabourService
        labourService = new LabourService();

        // Create test file and populate it with some data
        File testFile = new File(testFilePath);
        testFile.getParentFile().mkdirs();
        try (FileWriter writer = new FileWriter(testFile)) {
            writer.write("1,John,5000.0\n");
            writer.write("2,Jane,6000.0\n");
            writer.write("3,Mike,4000.0\n");
        }
    }

    @After
    public void tearDown() {
        // Clean up the test file after tests
        File testFile = new File(testFilePath);
        if (testFile.exists()) {
            testFile.delete();
        }
    }

    @Test
    public void testGetAll() {
        List<Labour> labours = labourService.getAll();
        assertEquals("Should return 3 labours from the file", 3, labours.size());
        assertEquals("First labour's name should be John", "John", labours.get(0).getName());
    }

    @Test
    public void testCreate() {
        Labour newLabour = new Labour("4", "Alice", 7000.0);
        labourService.create(newLabour);

        List<Labour> labours = labourService.getAll();
        assertEquals("Should return 4 labours after creation", 4, labours.size());
        assertEquals("Last labour's name should be Alice", "Alice", labours.get(3).getName());
    }

    @Test
    public void testUpdate() {
        Labour updatedLabour = new Labour("2", "Jane Doe", 6500.0);
        boolean result = labourService.update("2", updatedLabour);

        assertTrue("Update should return true for existing labour", result);

        List<Labour> labours = labourService.getAll();
        assertEquals("Labour list size should remain the same after update", 3, labours.size());
        assertEquals("Updated labour's name should be Jane Doe", "Jane Doe", labours.get(1).getName());
    }

    @Test
    public void testUpdateNonExistingLabour() {
        Labour updatedLabour = new Labour("5", "Nonexistent", 0.0);
        boolean result = labourService.update("5", updatedLabour);

        assertFalse("Update should return false for non-existing labour", result);
    }

    @Test
    public void testDelete() {
        labourService.delete("1");

        List<Labour> labours = labourService.getAll();
        assertEquals("Should return 2 labours after deletion", 2, labours.size());
        assertNotEquals("Deleted labour should no longer exist", "John", labours.get(0).getName());
    }
}

